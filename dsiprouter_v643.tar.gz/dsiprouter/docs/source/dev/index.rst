======================
The dSIPRouter Project
======================

.. toctree::
   :maxdepth: 2
   :caption: Python Modules
   :numbered:
   :titlesonly:
   :glob:
   :hidden:

    database <database.rst>
    dsiprouter <dsiprouter.rst>
    globals <globals.rst>
    modules <modules.rst>
    settings <settings.rst>
    shared <shared.rst>
    sysloginit <sysloginit.rst>
    util <util.rst>