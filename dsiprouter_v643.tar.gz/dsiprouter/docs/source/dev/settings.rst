settings
========

.. automodule:: settings
   :members:
   :undoc-members:
   :private-members:
   :special-members:
