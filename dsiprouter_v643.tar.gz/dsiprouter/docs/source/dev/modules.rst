=======
modules
=======

modules.api.api_routes
======================

.. automodule:: modules.api.api_routes
   :members:
   :undoc-members:
   :private-members:
   :special-members:

modules.api.cron_functions
==========================

.. automodule:: modules.api.cron_functions
   :members:
   :undoc-members:
   :private-members:
   :special-members:

modules.cdr.cron_functions
==========================

.. automodule:: modules.cdr.cron_functions
   :members:
   :undoc-members:
   :private-members:
   :special-members:

modules.domain.domain_routes
============================

.. automodule:: modules.domain.domain_routes
   :members:
   :undoc-members:
   :private-members:
   :special-members:

modules.flowroute
=================

.. automodule:: modules.flowroute
   :members:
   :undoc-members:
   :private-members:
   :special-members:

modules.frauddetection.fraud
============================

.. automodule:: modules.frauddetection.fraud
   :members:
   :undoc-members:
   :private-members:
   :special-members:

modules.fusionpbx.fusionpbx_sync_functions
==========================================

.. automodule:: modules.fusionpbx.fusionpbx_sync_functions
   :members:
   :undoc-members:
   :private-members:
   :special-members:
