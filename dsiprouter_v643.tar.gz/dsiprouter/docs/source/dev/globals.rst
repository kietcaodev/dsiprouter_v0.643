globals
=======

.. automodule:: globals
   :members:
   :undoc-members:
   :private-members:
   :special-members:
