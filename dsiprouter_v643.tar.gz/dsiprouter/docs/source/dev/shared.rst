shared
======

.. automodule:: shared
   :members:
   :undoc-members:
   :private-members:
   :special-members:
