sysloginit
==========

.. automodule:: sysloginit
   :members:
   :undoc-members:
   :private-members:
   :special-members:
