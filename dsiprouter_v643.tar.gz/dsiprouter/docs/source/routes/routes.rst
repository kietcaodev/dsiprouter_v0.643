==============
GUI/API Routes
==============

Summary
=======

.. qrefflask:: dsiprouter:app
  :undoc-static:

Details
=======

.. autoflask:: dsiprouter:app
  :undoc-static:
