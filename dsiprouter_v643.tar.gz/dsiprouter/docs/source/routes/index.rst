======================
The dSIPRouter Project
======================

.. toctree::
   :maxdepth: 2
   :caption: Routing Info
   :numbered:
   :titlesonly:
   :glob:
   :hidden:

    routes <routes.rst>
